package com.example.senddatatoblockchain;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;

import com.zbsnetwork.zbsjava.Account;
import com.zbsnetwork.zbsjava.DataEntry;
import com.zbsnetwork.zbsjava.PrivateKeyAccount;
import com.zbsnetwork.zbsjava.Transaction;
import com.zbsnetwork.zbsjava.Transactions;
import com.zbsnetwork.zbsjava.json.ZbsJsonMapper;

import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private final ZbsJsonMapper ZbsJsonMapper;

    public MainActivity() {
        this.ZbsJsonMapper = new ZbsJsonMapper((byte) 'T');
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String seed = "health lazy lens fix dwarf salad breeze myself silly december endless rent faculty report beyond";
        PrivateKeyAccount account = PrivateKeyAccount.fromSeed(seed, 0, Account.TESTNET);

        List<DataEntry<?>> data = new LinkedList<DataEntry<?>>();
        data.add(new DataEntry.StringEntry("Tree ID", "Tree Data"));

        try {

            // Sign a transaction
            Transaction tx = Transactions.makeDataTx(account,data, 300_000);
            Log.d("DataTx", ZbsJsonMapper.writeValueAsString(tx)); // This is the data to send to API below



            // Now POST this transaction

            new BroadcastTransactionTask().execute(ZbsJsonMapper.writeValueAsString(tx));



        } catch (Exception e) {
            e.printStackTrace();
        }


    }



private class BroadcastTransactionTask extends AsyncTask<String, Integer, Boolean> {
    protected Boolean doInBackground(String... txs) {

        URL url = null;
        try {
            url = new URL("https://node1.testnet-0bsnetwork.com/transactions/broadcast");



        HttpURLConnection con = (HttpURLConnection)url.openConnection();
        con.setRequestMethod("POST");

        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setRequestProperty("Accept", "application/json");

        con.setDoOutput(true);



        //JSON String need to be constructed for the specific resource.
        //We may construct complex JSON using any third-party JSON libraries such as jackson or org.json
        String jsonInputString = ZbsJsonMapper.writeValueAsString(txs[0]);
        Log.d("txData", jsonInputString);

        try(OutputStream os = con.getOutputStream()){
            byte[] input = jsonInputString.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int code = con.getResponseCode();
        System.out.println(code);

        try(BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))){
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println(response.toString());
        }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    protected void onProgressUpdate(Integer... progress) {

    }

    protected void onPostExecute(Long result) {

    }
}

}