package com.zbsnetwork.zbsjava;

public interface ApiJson {
}
