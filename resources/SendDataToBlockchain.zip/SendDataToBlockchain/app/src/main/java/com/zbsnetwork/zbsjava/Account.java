package com.zbsnetwork.zbsjava;

public interface Account {
    static byte MAINNET = (byte) 'Z';
    static byte TESTNET = (byte) 'T';
}
