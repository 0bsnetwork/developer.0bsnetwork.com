package com.zbsnetwork.zbsjava;

public interface ProofedObject<T> {
    T getObject();
}
