package com.zbsnetwork.zbsjava;

public interface WithId {
    ByteString getId();
}
