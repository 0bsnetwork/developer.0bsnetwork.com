package com.zbsnetwork.zbsjava;

public class Base64 {


    public static String encode(byte[] input) {
        return "base64:" + new String(android.util.Base64.encode(input, android.util.Base64.NO_WRAP));
    }

    public static byte[] decode(String input) {
        if (input.startsWith("base64:")) input = input.substring(7);
        return android.util.Base64.decode(input, android.util.Base64.NO_WRAP);
    }
}
