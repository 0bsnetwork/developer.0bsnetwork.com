import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Button, Text } from 'native-base';

export default function App() {

  buttonPressed = () => {
    fetch('https://signer.testnet-0bsnetwork.com/data', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        seed: 'leisure chat convince neither mutual chimney manage ranch foot differ gym busy horror spoon wise',
        data: [
          { "key": "integerVal", "value": 1 },
          { "key": "booleanVal", "value": true },
          { "key": "stringVal", "value": "hello" },
          { "key": "binaryVal", "value": [1, 2, 3, 4] }
        ],
      }),
    }).then(dataReponse => console.log(dataReponse));
  }
  return (
    <View style={styles.container}>
      <Button primary onPress={this.buttonPressed}><Text> Save Data </Text></Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
